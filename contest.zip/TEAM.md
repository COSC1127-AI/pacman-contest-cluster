# Team Information

**Course:** _[fill your course code and name]_

**Semester:** Semester 2, 2020

**Instructor:** _[name of your instructor]_

**Team name:** _[replace this with team name in plan text]_

**Team members:**

* Student 1's Student number - Full Name - Student email - Student Github id
* Student 2's Student number - Full Name - Student email - Student Github id
* Student 3's Student number - Full Name - Student email - Student Github id

Replace the lines above with the correct details of members. Delete or add lines as needed.

Student numbers should just be the **numbers**.