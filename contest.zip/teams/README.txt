Here one has to include the teams available
